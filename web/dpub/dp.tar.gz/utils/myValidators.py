#coding:utf-8

def checkTheNum(minnum,data):
    if len(data)< minnum:
        return False
    else
        return True

